/*
   BiNoM Cytoscape Plugin
   Copyright (C) 2006-2007 Curie Institute, 26 rue d'Ulm, 75005 Paris - FRANCE

   BiNoM Cytoscape Plugin is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   BiNoM Cytoscape plugin is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/*
  BiNoM authors:
	Andrei Zinovyev : http://www.ihes.fr/~zinovyev
	Eric Viara : http://www.sysra.com/viara
	Laurence Calzone :	http://leibniz.biol.vt.edu/people/laurence/laurence.html
*/
package fr.curie.BiNoM.cytoscape.biopax;
import fr.curie.BiNoM.cytoscape.lib.*;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.task.Task;
import cytoscape.task.TaskMonitor;
import cytoscape.visual.VisualMappingManager;
import cytoscape.visual.VisualStyle;
import java.io.*;
import cytoscape.task.ui.JTaskConfig;

import edu.rpi.cs.xgmml.*;
import cytoscape.CyNetwork;
import cytoscape.CyNode;
import cytoscape.CyEdge;
import cytoscape.view.CyNetworkView;
import cytoscape.data.Semantics;
import cytoscape.visual.*;
import java.io.InputStream;

import java.io.File;
import java.net.URL;

import fr.curie.BiNoM.pathways.wrappers.*;

import fr.curie.BiNoM.pathways.BioPAXToCytoscapeConverter;

public class BioPAXImport implements Task {
    private TaskMonitor taskMonitor;
    private String bioPaxName;
    private CyNetwork cyNetwork;
    private BioPAXToCytoscapeConverter.Option bioPaxOption;
    private int bioPaxAlgos[];
    private File file;
    private URL url;
    private static java.util.HashMap network_bw = new java.util.HashMap();

    public BioPAXImport(File file, URL url, String name, int algos[],
			BioPAXToCytoscapeConverter.Option option) {
	this.file = file;
	this.url = url;

        this.bioPaxAlgos = algos;
	int idx = name.lastIndexOf('.');
	if (idx >= 0)
	    name = name.substring(0, idx);

	idx = name.lastIndexOf('/');
	if (idx >= 0)
	    name = name.substring(idx+1, name.length());

        this.bioPaxName = name;
	this.bioPaxOption = option;
    }

    public void halt() {
    }

    public void setTaskMonitor(TaskMonitor taskMonitor)
            throws IllegalThreadStateException {
        this.taskMonitor = taskMonitor;
    }

    public String getTitle() {
	return "BiNoM: Import BioPAX " + bioPaxName;
    }

    public CyNetwork getCyNetwork() {
	return cyNetwork;
    }

    public void run() {
	try {
	    for (int n = 0; n < bioPaxAlgos.length && bioPaxAlgos[n] != 0; n++) {
		InputStream is;
		if (url != null)
		    is = url.openStream();
		else
		    is = new FileInputStream(file);

		BioPAXToCytoscapeConverter.Graph graph =
		    BioPAXToCytoscapeConverter.convert
		    (bioPaxAlgos[n],
		     is,
		     makeName(bioPaxAlgos[n]),
		     bioPaxOption);
                //XGMML.saveToXMGML(graph.graphDocument,"temp.xgmml");

		if (graph != null) {
		    /*cyNetwork = NetworkFactory.createNetwork
			(makeName(bioPaxAlgos[n]),
			 graph.graphDocument,
			 BioPAXVisualStyleDefinition.getInstance(),
			 true,
			 taskMonitor);*/

		    if (cyNetwork != null && bioPaxAlgos[n] ==
			BioPAXToCytoscapeConverter.REACTION_NETWORK_CONVERSION)
			network_bw.put(cyNetwork, graph.biopax);
		}

		is.close();
	    }
	}
	catch(Exception e) {
	    e.printStackTrace();
	    taskMonitor.setPercentCompleted(100);
	    taskMonitor.setStatus("Error importing BioPAX file " +
				  bioPaxName + ": " + e);
	}
    }

    String makeName(int algo) {
	if (algo == BioPAXToCytoscapeConverter.REACTION_NETWORK_CONVERSION)
	    return bioPaxName + " RN";

	if (algo == BioPAXToCytoscapeConverter.PATHWAY_STRUCTURE_CONVERSION)
	    return bioPaxName + " PS";

	if (algo == BioPAXToCytoscapeConverter.PROTEIN_PROTEIN_INTERACTION_CONVERSION)
	    return bioPaxName + " PP";

	return bioPaxName + " XX";
    }

    public static boolean isBioPAXNetwork(CyNetwork cyNetwork) {
	return network_bw.get(cyNetwork) != null;
    }

    public static BioPAX getBioPAX(CyNetwork cyNetwork) {
	return (BioPAX)network_bw.get(cyNetwork);
    }
}

