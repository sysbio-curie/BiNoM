package fr.curie.BiNoM.pathways.test;

import java.io.*;
//import javolution.xml.*;

public class testJavolution {
  public static void main(String[] args) {

    /*try{

    XMLObjectReader reader = XMLObjectReader.newInstance(new FileInputStream("c:/datas/biopax/reactomerel19/hs2.xgmml"));
    while (reader.hasNext()) {
       reader.read("node");
    }
     reader.close();

    }catch(Exception e){
      e.printStackTrace();
    }*/

  }
}