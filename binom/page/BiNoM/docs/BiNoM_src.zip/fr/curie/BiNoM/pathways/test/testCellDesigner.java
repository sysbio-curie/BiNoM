package fr.curie.BiNoM.pathways.test;

import java.util.*;
import java.io.*;

import org.sbml.x2001.ns.celldesigner.*;
import org.apache.xmlbeans.*;

import fr.curie.BiNoM.pathways.wrappers.*;
import fr.curie.BiNoM.pathways.utils.*;

public class testCellDesigner {

	public static void main(String[] args) {
		try{
			
			// For Laurence
			SbmlDocument cd1 = CellDesigner.loadCellDesigner("c:/datas/calzone/paper/280607.xml"); 
			SbmlDocument cdt = CellDesigner.loadCellDesigner("c:/datas/calzone/paper/target_genes.xml");
			HashMap comments = new HashMap();
			
			HashMap objects = CellDesigner.getAllObjectsHash(cdt);
			HashMap objects1 = CellDesigner.getAllObjectsHash(cd1);
			
			/*for(int i=0;i<cdt.getSbml().getModel().getListOfReactions().sizeOfReactionArray();i++){
				ReactionDocument.Reaction r = cdt.getSbml().getModel().getListOfReactions().getReactionArray(i);
				String type = Utils.getValue(r.getAnnotation().getCelldesignerReactionType());
				if(type.startsWith("TRANSCRIPTIONAL")||type.startsWith("UNKNOWN"))
				if(r.getListOfReactants().getSpeciesReferenceArray().length==1)
				if(r.getListOfProducts().getSpeciesReferenceArray().length==1){
					String id1 = r.getListOfReactants().getSpeciesReferenceArray(0).getSpecies();
					SpeciesDocument.Species sp1 = (SpeciesDocument.Species)objects.get(id1);
					String id2 = r.getListOfProducts().getSpeciesReferenceArray(0).getSpecies();
					SpeciesDocument.Species sp2 = (SpeciesDocument.Species)objects.get(id2);
					String key = Utils.getValue(sp1.getName())+"->"+Utils.getValue(sp2.getName());
					if(r.getNotes()!=null)
					//if(r.getNotes().getHtml()!=null)
						{
						String note = Utils.getText(r.getNotes()).trim();
						System.out.println(key+" : "+note);
						comments.put(key, note);
					}
				}
			}*/
			
			// Load E2F.txt file
			LineNumberReader lr = new LineNumberReader(new FileReader("c:/datas/calzone/paper/E2F_new290607.txt"));
			String s = null;
			int count=0;
			while((s=lr.readLine())!=null){
				//System.out.println((++count));
				StringTokenizer st = new StringTokenizer(s,"\t");
				String sp1 = st.nextToken();
				String sp2 = st.nextToken();
				String key = sp1.trim()+"->"+sp2.trim();
				try{
				String comm = st.nextToken();
				StringTokenizer st1 = new StringTokenizer(comm," ");
				String comment = "";
				while(st1.hasMoreTokens()){
					comment+="PMID: "+st1.nextToken()+"\n";
				}
				comments.put(key.trim(),comment);
				}catch(Exception e){
					
				}
			}
			
			HashMap allKeys = new HashMap();
			
			int found = 0;
			for(int i=0;i<cd1.getSbml().getModel().getListOfReactions().sizeOfReactionArray();i++){
				ReactionDocument.Reaction r = cd1.getSbml().getModel().getListOfReactions().getReactionArray(i);
				String type = Utils.getValue(r.getAnnotation().getCelldesignerReactionType());
				if(type.startsWith("TRANSCRIPTIONAL")||type.startsWith("UNKNOWN"))
				if(r.getListOfReactants().getSpeciesReferenceArray().length==1)
				if(r.getListOfProducts().getSpeciesReferenceArray().length==1){
					String id1 = r.getListOfReactants().getSpeciesReferenceArray(0).getSpecies();
					SpeciesDocument.Species sp1 = (SpeciesDocument.Species)objects1.get(id1);
					String id2 = r.getListOfProducts().getSpeciesReferenceArray(0).getSpecies();
					SpeciesDocument.Species sp2 = (SpeciesDocument.Species)objects1.get(id2);
					if((sp1!=null)&&(sp2!=null)){
					String key = (Utils.getValue(sp1.getName()).trim()+"->"+Utils.getValue(sp2.getName()).trim()).trim();
					allKeys.put(key, r);
					System.out.println(r.getId()+"\t"+key);
					if(comments.get(key)!=null){
						System.out.println((++found)+") For "+r.getId()+" "+key+" found \n");
						if(r.getNotes()!=null)
							//if(r.getNotes().getHtml()!=null)
								{
								String note = Utils.getText(r.getNotes()).trim();
								//System.out.println(key+" : "+note);
								NotesDocument.Notes notes = r.addNewNotes();
								HtmlDocument.Html html = notes.addNewHtml();
								BodyDocument.Body body = html.addNewBody();
								String comment = (String)comments.get(key);
								StringTokenizer st = new StringTokenizer(comment,"\n"); 
								String finalComment = note;
								while(st.hasMoreTokens()){
									String text = st.nextToken().trim();
									if(finalComment.indexOf(text)<0)
										finalComment+=text+"\n";
								}
								Utils.setValue(body,finalComment.trim());
							}else{
								NotesDocument.Notes notes = r.addNewNotes();
								HtmlDocument.Html html = notes.addNewHtml();
								BodyDocument.Body body = html.addNewBody();
								Utils.setValue(body,(String)comments.get(key));
							}
						System.out.println(Utils.getText(r.getNotes()));
					}
					}
				}
			}

			Vector notFoundinTxt = new Vector();
			Vector notFoundinFile = new Vector();

			count =0;
			for(Iterator it=comments.keySet().iterator();it.hasNext();){
				String key = (String)it.next();
				//if(key.equals("E2F4->UXT"))
					//System.out.println("Comment key "+key+" "+key.length());
				if(allKeys.get(key)==null)
					System.out.println((++count)+") "+key+" not found in file");
			}
			count =0;
			for(Iterator it=allKeys.keySet().iterator();it.hasNext();){
				String key = (String)it.next();
				if(comments.get(key)==null)
					System.out.println((++count)+") "+key+" not found in text");
			}

			//System.out.println("Check "+allKeys.get("E2F4->UXT"));			
			
			System.out.println("Saving");
			CellDesigner.saveCellDesigner(cd1, "c:/datas/calzone/paper/280607prime_.xml");
			
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
