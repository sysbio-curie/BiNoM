/*
   BiNoM Cytoscape Plugin
   Copyright (C) 2006-2007 Curie Institute, 26 rue d'Ulm, 75005 Paris - FRANCE

   BiNoM Cytoscape Plugin is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   BiNoM Cytoscape plugin is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/*
  BiNoM authors:
	Andrei Zinovyev : http://www.ihes.fr/~zinovyev
	Eric Viara : http://www.sysra.com/viara
	Laurence Calzone :	http://leibniz.biol.vt.edu/people/laurence/laurence.html
*/
package fr.curie.BiNoM.cytoscape.celldesigner;

import fr.curie.BiNoM.cytoscape.lib.*;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.task.Task;
import cytoscape.task.TaskMonitor;
import cytoscape.visual.VisualMappingManager;
import cytoscape.visual.VisualStyle;
import java.io.*;
import cytoscape.task.ui.JTaskConfig;

import edu.rpi.cs.xgmml.*;
import cytoscape.CyNetwork;
import cytoscape.CyNode;
import cytoscape.CyEdge;
import cytoscape.view.CyNetworkView;
import cytoscape.data.Semantics;
import cytoscape.visual.*;
import java.io.InputStream;

import java.util.Vector;
import java.util.StringTokenizer;
import java.util.Iterator;
import java.util.HashMap;

import java.io.File;
import java.net.URL;
import giny.view.NodeView;

import org.sbml.x2001.ns.celldesigner.*;
import fr.curie.BiNoM.pathways.CellDesignerToCytoscapeConverter;

import fr.curie.BiNoM.pathways.wrappers.*;
import fr.curie.BiNoM.cytoscape.celldesigner.CellDesignerImportTask;
import fr.curie.BiNoM.pathways.CytoscapeToCellDesignerConverter;

import fr.curie.BiNoM.pathways.utils.Utils;

import javax.swing.JOptionPane;

public class CellDesignerExportTask implements Task {
    private TaskMonitor taskMonitor;
    private CyNetwork cyNetwork;
    private File file;
    private static java.util.HashMap network_bw = new java.util.HashMap();
    private boolean merge;

    public CellDesignerExportTask(File file, boolean merge) {
	this.file = file;
	this.merge = merge;
    }

    public void halt() {
    }

    public void setTaskMonitor(TaskMonitor taskMonitor)
            throws IllegalThreadStateException {
        this.taskMonitor = taskMonitor;
    }

    public String getTitle() {
	return "BiNoM: Export CellDesigner " + file.getPath();
    }

    public CyNetwork getCyNetwork() {
	return cyNetwork;
    }

    public void run() {
	try {
            CyNetwork network = Cytoscape.getCurrentNetwork();

	    SbmlDocument sbml = CellDesignerSourceDB.getInstance().getCellDesigner(network);
	    if (sbml != null) {
		// celldesigner -> celldesigner
		Vector species = new Vector();
		Vector speciesAliases = new Vector();
		Vector reactions = new Vector();
		Vector degraded = new Vector();

		findSBMLSpeciesAndReactions(sbml, species, speciesAliases,
					    reactions, degraded);
		
		if(isColorChanged(network))
			assignCellDesignerColors(sbml, network);

		//CytoscapeToCellDesignerConverter.filterIDs(sbml, species,
		//					   speciesAliases,
		//					   reactions,
		//					   degraded);

		if (merge) {
                  try {
		      SbmlDocument sbmlin = CellDesigner.loadCellDesigner(file.getAbsolutePath());
                      //String err = null;
                      String err = CellDesignerToCytoscapeConverter.checkAndModifySpeciesIDs(sbmlin,sbml);
                      if(err!=null){
                        JOptionPane.showMessageDialog(Cytoscape.getDesktop(),err+"\n Merge has not been done.");
                      }else{
                        err = CellDesignerToCytoscapeConverter.checkAndModifyEntitiesIDs(sbmlin,sbml);
                        if(err!=null){
                          JOptionPane.showMessageDialog(Cytoscape.getDesktop(),err+"\n Merge has not been done.");
                        }else{

                        CytoscapeToCellDesignerConverter.filterIDsCompleteReactions
                            (sbml, species,
                             speciesAliases,
                             reactions,
                             degraded);

                        CellDesignerToCytoscapeConverter.mergeCellDesignerFiles(sbmlin,sbml);
                        sbml = sbmlin;

    		        CellDesigner.saveCellDesigner(sbml, file.getAbsolutePath());
                        }
                      }
                  } catch(Exception e) {
		      System.out.println("Error in trying merging files...");
		      e.printStackTrace();
		      taskMonitor.setPercentCompleted(100);
		      taskMonitor.setStatus("Error in merging CellDesigner files " +
				  file.getAbsolutePath() + ": " + e);
                  }
                } else {
                  CytoscapeToCellDesignerConverter.filterIDsCompleteReactions
                      (sbml, species,
                       speciesAliases,
                       reactions,
                       degraded);
    		  CellDesigner.saveCellDesigner(sbml, file.getAbsolutePath());
                }

	    }

	    taskMonitor.setPercentCompleted(100);
	}
	catch(Exception e) {
	    e.printStackTrace();
	    taskMonitor.setPercentCompleted(100);
	    taskMonitor.setStatus("Error exporting CellDesigner file " +
				  file.getAbsolutePath() + ": " + e);
	}
    }

    public static void findSBMLSpeciesAndReactions(SbmlDocument sbml,
						   Vector species,
						   Vector speciesAliases,
						   Vector reactions,
						   Vector degraded) {
	CyNetworkView view = Cytoscape.getCurrentNetworkView();
	cytoscape.data.CyAttributes nodeAttrs = Cytoscape.getNodeAttributes();

	for (Iterator i = view.getNodeViewsIterator(); i.hasNext(); ) {
	    NodeView nView = (NodeView)i.next();
	    CyNode node = (CyNode)nView.getNode();
	    Object o;

	    o = nodeAttrs.getStringAttribute(node.getIdentifier(),
					     "CELLDESIGNER_SPECIES");
	    if (o != null)
		species.add(o);

	    o = nodeAttrs.getStringAttribute(node.getIdentifier(),
					     "CELLDESIGNER_ALIAS");
	    if (o != null)
		speciesAliases.add(o);

	    o = nodeAttrs.getStringAttribute(node.getIdentifier(),
					     "CELLDESIGNER_REACTION");
	    if (o != null)
		reactions.add(o);

	}

	int cnt = sbml.getSbml().getModel().getListOfSpecies().getSpeciesArray().length;
	for (int i = 0; i < cnt; i++) {
	    SpeciesDocument.Species sp = sbml.getSbml().getModel().getListOfSpecies().getSpeciesArray(i);
	    String cl = Utils.getValue(sp.getAnnotation().getCelldesignerSpeciesIdentity().getCelldesignerClass());

	    if (cl.equals("DEGRADED"))
		degraded.add(sp.getId());
	}
    }
    
    public boolean isColorChanged(CyNetwork network){
    	boolean changed = false;
    	java.util.Iterator i = network.nodesIterator();
    	cytoscape.data.CyAttributes nodeAttrs = Cytoscape.getNodeAttributes();
    	while (i.hasNext()) {
    	    CyNode node = (CyNode)i.next();
    	    String id = node.getIdentifier();
            CyNetworkView networkView = Cytoscape.getNetworkView(network.getIdentifier());
            NodeView nv = networkView.getNodeView(node);
            String nodeType = nodeAttrs.getStringAttribute(id, "CELLDESIGNER_NODE_TYPE");
            try{
                java.awt.Color colorObject = Utils.convertPaintToColor(nv.getUnselectedPaint());
                Vector map = CellDesignerVisualStyleDefinition.getInstance().getNodeColorMapping();
                for(int k=0;k<map.size();k++){
                	CellDesignerVisualStyleDefinition.ObjectMapping mapping = (CellDesignerVisualStyleDefinition.ObjectMapping)map.get(k);
                	if(mapping.getAttributeValue().equals(nodeType)){
                		if(!mapping.getMappingValue().equals(colorObject))
                			changed = true;
                	}
                	//System.out.println(mapping.getAttributeValue()+"->"+mapping.getMappingValue().toString());
                }
            }catch(Exception e){
            	e.printStackTrace();
            }
    	}
    	return changed;
    }
    
    public void assignCellDesignerColors(SbmlDocument sbml, CyNetwork network){
    	HashMap colorTable = new HashMap();
    	java.util.Iterator i = network.nodesIterator();
    	cytoscape.data.CyAttributes nodeAttrs = Cytoscape.getNodeAttributes();
    	while (i.hasNext()) {
    	    CyNode node = (CyNode)i.next();
    	    String id = node.getIdentifier();
            CyNetworkView networkView = Cytoscape.getNetworkView(network.getIdentifier());
            NodeView nv = networkView.getNodeView(node);

            
            try{
            
            java.awt.Color colorObject = Utils.convertPaintToColor(nv.getUnselectedPaint());
            
            int rc = colorObject.getRed();
            int gc = colorObject.getGreen();
            int bc = colorObject.getBlue();
            String rcs = Integer.toHexString(rc); if(rcs.length()==1) rcs="0"+rcs;
            String gcs = Integer.toHexString(gc); if(gcs.length()==1) gcs="0"+gcs;
            String bcs = Integer.toHexString(bc); if(bcs.length()==1) bcs="0"+bcs;
            String color = "ff"+rcs+gcs+bcs;
            
            //System.out.println("NODE COLOR "+id+" : "+rcs+","+gcs+","+bcs);
 	    	String species = nodeAttrs.getStringAttribute(id, "CELLDESIGNER_SPECIES");
    	    if (species!= null)if(!species.trim().equals("")){
    	    	colorTable.put(species,color);
    	    }
    	    
            }catch(Exception e){
            	e.printStackTrace();
            }
    	    
    	    
    	}
    	CytoscapeToCellDesignerConverter.assignColorsFromTable(sbml, colorTable);
    }
    
    
}



