/*
   BiNoM Cytoscape Plugin
   Copyright (C) 2006-2007 Curie Institute, 26 rue d'Ulm, 75005 Paris - FRANCE

   BiNoM Cytoscape Plugin is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   BiNoM Cytoscape plugin is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/*
  BiNoM authors:
	Andrei Zinovyev : http://www.ihes.fr/~zinovyev
	Eric Viara : http://www.sysra.com/viara
	Laurence Calzone :	http://leibniz.biol.vt.edu/people/laurence/laurence.html
*/

package fr.curie.BiNoM.pathways.converters;

import java.io.*;
import java.util.*;
import fr.curie.BiNoM.pathways.wrappers.*;

public class Transpath2BioPAX {
  public static void main(String[] args) {
    try{

      String prefix = "c:/datas/biobase/";

      Transpath tp = new Transpath();
      tp.initializeModel();
      tp.biopax.makeCompartments();

      /*tp.loadFromFile(prefix+"molecule.xml");
      //tp.loadFromFile(prefix+"gene.xml");
      tp.createAccessionTable("c:/datas/biobase/accmolecules");
      System.exit(0);*/

      /*tp.speciesFilter = new Vector();
      tp.speciesFilter.add("human, Homo sapiens");
      tp.speciesFilter.add("mouse, Mus musculus");
      tp.speciesFilter.add("rat, Rattus norvegicus");
      tp.speciesFilter.add("taxonomic class Mammalia");*/

      /*System.out.println("Converting genes...");
      tp.loadFromFile(prefix+"gene.xml");
      tp.populateModel();
      tp.biopax.saveToFile(prefix+"gene.owl",tp.biopax.biopaxmodel);*/

      System.out.println("Loading annotations...");
      Transpath annotations = new Transpath();
      String annf = prefix+"annotate.xml";
      if(args.length>1)
        annf = args[1];
      System.out.println("from "+annf);
      annotations.loadFromFile(annf);
      tp.annotations = annotations.network;

      System.out.println("Converting molecules...");
      //String filename = prefix+"molecule.xml";
      String filename = prefix+"test/test1.xml";
      if(args.length>0)
        filename = args[0];
      System.out.println("from "+filename);
      tp.loadFromFile(filename);
      tp.populateModel();
      //tp.biopax.saveToFile("molecule.owl",tp.biopax.biopaxmodel);
      tp.biopax.saveToFile(prefix+"test/test1.owl",tp.biopax.biopaxmodel);

      /*System.out.println("Converting reactions...");

      System.out.println("Loading annotations...");
      Transpath annotations = new Transpath();
      String annf = prefix+"annotate.xml";      
      if(args.length>1)
        annf = args[1];
      System.out.println("from "+annf);
      annotations.loadFromFile(annf);
      tp.annotations = annotations.network;

      System.out.println("Loading reactions...");
      String filename = prefix+"reaction.xml";
      if(args.length>0)
        filename = args[0];
      System.out.println("from "+filename);
      tp.loadFromFile(filename);
      //tp.typeOfReactionExtraction = tp.SEMANTIC;
      //tp.typeOfReactionExtraction = tp.PATHWAY_STEP;
      tp.typeOfReactionExtraction = tp.MOLECULAR_EVIDENCE;
      System.out.println("Populating model...");
      tp.populateModel();
      //tp.biopax.saveToFile(prefix+"reaction_evidence.owl",tp.biopax.biopaxmodel);
      tp.biopax.saveToFile("reaction_evidence.owl",tp.biopax.biopaxmodel);*/

      /*System.out.println("Loading references...");
      tp.loadFromFile(prefix+"reference.xml");
      tp.populateModel();
      tp.biopax.saveToFile(prefix+"reference.owl",tp.biopax.biopaxmodel);*/

      /*System.out.println("Loading pathways...");
      tp.loadFromFile(prefix+"pathway.xml");
      tp.populateModel();
      tp.biopax.saveToFile(prefix+"pathway.owl",tp.biopax.biopaxmodel);*/


    }catch(Exception e){
      e.printStackTrace();
    }
  }
}