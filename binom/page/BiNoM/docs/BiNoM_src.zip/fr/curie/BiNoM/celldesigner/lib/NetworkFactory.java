/*
   BiNoM Cytoscape Plugin
   Copyright (C) 2006-2007 Curie Institute, 26 rue d'Ulm, 75005 Paris - FRANCE

   BiNoM Cytoscape Plugin is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   BiNoM Cytoscape plugin is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/*
  BiNoM authors:
	Andrei Zinovyev : http://www.ihes.fr/~zinovyev
	Eric Viara : http://www.sysra.com/viara
	Laurence Calzone :	http://leibniz.biol.vt.edu/people/laurence/laurence.html
*/
package fr.curie.BiNoM.celldesigner.lib;

import java.io.*;
import edu.rpi.cs.xgmml.GraphDocument;

import fr.curie.BiNoM.cytoscape.biopax.BioPAXSourceDB;
import fr.curie.BiNoM.pathways.utils.*;
import fr.curie.BiNoM.pathways.wrappers.*;

import jp.sbi.celldesigner.plugin.PluginAction;
import jp.sbi.celldesigner.plugin.PluginModel;
import jp.sbi.celldesigner.plugin.PluginListOf;
import jp.sbi.celldesigner.plugin.PluginSBase;
import jp.sbi.celldesigner.plugin.PluginReaction;
import jp.sbi.celldesigner.plugin.PluginSpecies;
import jp.sbi.celldesigner.plugin.PluginSpeciesAlias;
import jp.sbi.celldesigner.plugin.PluginModificationResidue;
import jp.sbi.celldesigner.plugin.util.PluginSpeciesSymbolType;
import jp.sbi.celldesigner.plugin.CellDesignerPlugin;

import java.util.Vector;
import java.util.HashMap;

public class NetworkFactory {

    public static final String ATTR_SEP = "@@@";

    public static void createNetwork
	(PluginModel model,
	 CellDesignerPlugin plugin,
	 GraphDocument graphDocument) throws Exception {

	edu.rpi.cs.xgmml.GraphicGraph grf = graphDocument.getGraph();
	edu.rpi.cs.xgmml.GraphicNode nodes[] = grf.getNodeArray();
	edu.rpi.cs.xgmml.GraphicEdge edges[] = grf.getEdgeArray();

	System.out.println("NETWORK_FACTORY");

	for (int n = 0; n < nodes.length; n++) {
	    edu.rpi.cs.xgmml.GraphicNode node = nodes[n];
	    PluginSpecies species = new PluginSpecies(PluginSpeciesSymbolType.PROTEIN , (String)node.getLabel());
	    edu.rpi.cs.xgmml.AttDocument.Att attrs[] = node.getAttArray();
	    
	    for (int j = 0; j < attrs.length; j++) {
		edu.rpi.cs.xgmml.AttDocument.Att attr = attrs[j];
		String attrValue = attr.getValue();
		if (attrValue != null) {
		    System.out.println(attr.getLabel() + " -> " + attr.getValue());
		}
	    }

	    model.addSpecies(species);
	    species.getSpeciesAlias(0).setFramePosition(40+n*10, 40+n*30);
	    species.getSpeciesAlias(0).setFrameSize(8 * node.getLabel().length(), 30);
	    plugin.notifySBaseAdded(species);
	}
	
	for (int n = 0; n < edges.length; n++) {
	    edu.rpi.cs.xgmml.GraphicEdge edge = edges[n];
	    System.out.println("edge " + edge.getLabel());
	    edu.rpi.cs.xgmml.AttDocument.Att attrs[] = edge.getAttArray();
	    
	    for (int j = 0; j < attrs.length; j++) {
		edu.rpi.cs.xgmml.AttDocument.Att attr = attrs[j];
		String attrValue = attr.getValue();
		if (attrValue != null) {
		    System.out.println(attr.getLabel() + " -> " + attr.getValue());
		}
	    }
	}
    }
}
