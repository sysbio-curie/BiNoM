/*
   BiNoM Cytoscape Plugin
   Copyright (C) 2006-2007 Curie Institute, 26 rue d'Ulm, 75005 Paris - FRANCE

   BiNoM Cytoscape Plugin is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   BiNoM Cytoscape plugin is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/*
  BiNoM authors:
	Andrei Zinovyev : http://www.ihes.fr/~zinovyev
	Eric Viara : http://www.sysra.com/viara
	Laurence Calzone :	http://leibniz.biol.vt.edu/people/laurence/laurence.html
*/
package fr.curie.BiNoM.cytoscape.celldesigner;

import fr.curie.BiNoM.cytoscape.lib.*;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.task.Task;
import cytoscape.task.TaskMonitor;
import cytoscape.visual.VisualMappingManager;
import cytoscape.visual.VisualStyle;
import java.io.*;
import cytoscape.task.ui.JTaskConfig;

import edu.rpi.cs.xgmml.*;
import cytoscape.CyNetwork;
import cytoscape.CyNode;
import cytoscape.CyEdge;
import cytoscape.view.CyNetworkView;
import cytoscape.data.Semantics;
import cytoscape.visual.*;
import java.io.InputStream;

import java.util.Vector;
import java.util.Iterator;

import java.io.File;
import java.net.URL;
import giny.view.NodeView;

import org.sbml.x2001.ns.celldesigner.*;
import fr.curie.BiNoM.pathways.CellDesignerToCytoscapeConverter;

import fr.curie.BiNoM.pathways.wrappers.CellDesigner;
import fr.curie.BiNoM.cytoscape.celldesigner.CellDesignerImport;
import fr.curie.BiNoM.pathways.CytoscapeToCellDesignerConverter;

import fr.curie.BiNoM.pathways.utils.Utils;

public class CellDesignerExport implements Task {
    private TaskMonitor taskMonitor;
    private CyNetwork cyNetwork;
    private File file;
    private static java.util.HashMap network_bw = new java.util.HashMap();

    public CellDesignerExport(File file) {
	this.file = file;
    }

    public void halt() {
    }

    public void setTaskMonitor(TaskMonitor taskMonitor)
            throws IllegalThreadStateException {
        this.taskMonitor = taskMonitor;
    }

    public String getTitle() {
	return "BiNoM: Export CellDesigner " + file.getPath();
    }

    public CyNetwork getCyNetwork() {
	return cyNetwork;
    }

    public void run() {
	try {
            CyNetwork network = Cytoscape.getCurrentNetwork();

	    SbmlDocument sbml = CellDesignerImport.getCellDesigner(network);
	    if (sbml != null) {
		// celldesigner -> celldesigner
		Vector species = new Vector();
		Vector speciesAliases = new Vector();
		Vector reactions = new Vector();
		Vector degraded = new Vector();

		findSBMLSpeciesAndReactions(sbml, species, speciesAliases,
					    reactions, degraded);

		CytoscapeToCellDesignerConverter.filterIDs(sbml, species,
							   speciesAliases,
							   reactions,
							   degraded);
		CellDesigner.saveCellDesigner(sbml, file.getAbsolutePath());

	    }

	    taskMonitor.setPercentCompleted(100);
	}
	catch(Exception e) {
	    e.printStackTrace();
	    taskMonitor.setPercentCompleted(100);
	    taskMonitor.setStatus("Error exporting CellDesigner file " +
				  file.getAbsolutePath() + ": " + e);
	}
    }

    public static void findSBMLSpeciesAndReactions(SbmlDocument sbml,
						   Vector species,
						   Vector speciesAliases,
						   Vector reactions,
						   Vector degraded) {
	CyNetworkView view = Cytoscape.getCurrentNetworkView();
	cytoscape.data.CyAttributes nodeAttrs = Cytoscape.getNodeAttributes();

	for (Iterator i = view.getNodeViewsIterator(); i.hasNext(); ) {
	    NodeView nView = (NodeView)i.next();
	    CyNode node = (CyNode)nView.getNode();
	    Object o;

	    o = nodeAttrs.getStringAttribute(node.getIdentifier(),
					     "CELLDESIGNER_SPECIES");
	    if (o != null)
		species.add(o);

	    o = nodeAttrs.getStringAttribute(node.getIdentifier(),
					     "CELLDESIGNER_ALIAS");
	    if (o != null)
		speciesAliases.add(o);

	    o = nodeAttrs.getStringAttribute(node.getIdentifier(),
					     "CELLDESIGNER_REACTION");
	    if (o != null)
		reactions.add(o);

	}

	int cnt = sbml.getSbml().getModel().getListOfSpecies().getSpeciesArray().length;
	for (int i = 0; i < cnt; i++) {
	    SpeciesDocument.Species sp = sbml.getSbml().getModel().getListOfSpecies().getSpeciesArray(i);
	    String cl = Utils.getValue(sp.getAnnotation().getCelldesignerSpeciesIdentity().getCelldesignerClass());

	    if (cl.equals("DEGRADED"))
		degraded.add(sp.getId());
	}
    }    
}


    
