
package fr.curie.BiNoM.celldesigner.biopax;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;

import javax.swing.JOptionPane;

import jp.sbi.celldesigner.plugin.PluginAction;
import jp.sbi.celldesigner.plugin.PluginModel;
import jp.sbi.celldesigner.plugin.CellDesignerPlugin;

import fr.curie.BiNoM.pathways.BioPAXToCytoscapeConverter;
import fr.curie.BiNoM.celldesigner.lib.NetworkFactory;

public class BioPAXImportFromFile extends PluginAction {

    private CellDesignerPlugin plugin;
    private PluginModel model;

    public BioPAXImportFromFile(CellDesignerPlugin plugin) {
	this.plugin = plugin;
    }

    public void myActionPerformed(ActionEvent e) {
	try {
	    String fileName = "/home/viara/projects/BiNoM/examples/M-Phase2.owl";

	    // This example reads BioPAX, creates reaction network from it, 
	    // decomposes the network into connected components,
	    // and saves each component to new BioPAX owl file and to SBML format
	    BioPAXToCytoscapeConverter.Graph graph = 
		BioPAXToCytoscapeConverter.convert
		(
		 BioPAXToCytoscapeConverter.REACTION_NETWORK_CONVERSION,
		 fileName,
		 "Apoptosis",
		 new BioPAXToCytoscapeConverter.Option()
		 );

	    /*
	    if (model == null) {
		model = plugin.getSelectedModel();
	    }
	    */
	    model = new PluginModel("test");
	    //plugin.modelOpened(model);
	    //plugin.notifySBaseAdded(model);
	    System.out.println("MODEL SIZE: " + plugin.getAllModels().size());

	    NetworkFactory.createNetwork(model, plugin, graph.graphDocument);

	} catch(Exception exc) {
	    exc.printStackTrace();
	}
    }
}
