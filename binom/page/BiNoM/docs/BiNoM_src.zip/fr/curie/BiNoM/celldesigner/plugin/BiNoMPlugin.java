package fr.curie.BiNoM.celldesigner.plugin;

import jp.sbi.celldesigner.plugin.CellDesignerPlugin;
import jp.sbi.celldesigner.plugin.PluginMenu;
import jp.sbi.celldesigner.plugin.PluginMenuItem;
import jp.sbi.celldesigner.plugin.PluginSBase;

import fr.curie.BiNoM.celldesigner.biopax.BioPAXImportFromFile;

public class BiNoMPlugin extends CellDesignerPlugin {

    PluginMenuItem exportBioPAXMenuItem;
    PluginMenuItem exportCellDesignerMenuItem;
    PluginMenuItem exportSBMLMenuItem;
    PluginMenuItem saveBioPAXMenuItem;    
    PluginMenuItem syncBioPAXMenuItem;    
    PluginMenuItem associateBioPAXMenuItem;
    PluginMenuItem associateCellDesignerMenuItem;
    PluginMenuItem selectEdgesBetweendSelectedNodesMenuItem;
    PluginMenuItem showClipboardContentsMenuItem;
    PluginMenuItem setNodesAndEdgesMenuItem;
    PluginMenuItem addNodesAndEdgesMenuItem;
    PluginMenuItem pasteNodesAndEdgesMenuItem;
    PluginMenuItem toggleBioPAXNameMenuItem;
    PluginMenuItem listAllReactionsMenuItem;
    PluginMenuItem listAllNodesMenuItem;

    /**
     * 
     */
    public BiNoMPlugin(){
	BiNoMPluginAction action = new BiNoMPluginAction(this);
	/*
	PluginMenu menu  = new PluginMenu("BiNoM Plugin");
	item = new PluginMenuItem("Display Part of the Pathway", action);
	menu.add(item);
	addCellDesignerPluginMenu(menu);
	*/

        PluginMenu binomIOMenu = new PluginMenu("BiNoM I/O");
	addCellDesignerPluginMenu(binomIOMenu);

	BioPAXImportFromFile biopaxImportFromFile = new BioPAXImportFromFile(this);

        PluginMenuItem menuItem = new PluginMenuItem
	    ("Import BioPAX Document from file...", biopaxImportFromFile);
        binomIOMenu.add(menuItem);
        //menuItem.addActionListener(new BioPAXImportFromFile());

        menuItem = new PluginMenuItem
	    ("Import BioPAX Document from URL...", action);
        binomIOMenu.add(menuItem);
        //menuItem.addActionListener(new BioPAXImportFromURL());

        //binomIOMenu.addSeparator();

        binomIOMenu.addSeparator();

        menuItem = new PluginMenuItem
	    ("Import CellDesigner Document from file...", action);
        binomIOMenu.add(menuItem);
        //menuItem.addActionListener(new CellDesignerImportFromFile());

        menuItem = new PluginMenuItem
	    ("Import CellDesigner Document from URL...", action);

        binomIOMenu.add(menuItem);

        binomIOMenu.addSeparator();
        
        menuItem = new PluginMenuItem
	    ("Import influence network from AIN file...", action);
        binomIOMenu.add(menuItem);
        //menuItem.addActionListener(new ImportFromSimpleTextInfluenceFile());

        binomIOMenu.addSeparator();

        exportBioPAXMenuItem = new PluginMenuItem("Export current network to BioPAX...", action);
        binomIOMenu.add(exportBioPAXMenuItem);
        //exportBioPAXMenuItem.addActionListener(new BioPAXExportToFile());

        exportCellDesignerMenuItem = new PluginMenuItem("Export current network to CellDesigner...", action);
        binomIOMenu.add(exportCellDesignerMenuItem);
        //exportCellDesignerMenuItem.addActionListener(new CellDesignerExportToFile());

        exportSBMLMenuItem = new PluginMenuItem("Export current network to SBML...", action);
        binomIOMenu.add(exportSBMLMenuItem);
        //exportSBMLMenuItem.addActionListener(new SBMLExportToFile());
	
        
        binomIOMenu.addSeparator();        

        associateBioPAXMenuItem = new PluginMenuItem("Associate BioPAX Source...", action);
        binomIOMenu.add(associateBioPAXMenuItem);
        //associateBioPAXMenuItem.addActionListener(BioPAXAssociateSource.getInstance());

        saveBioPAXMenuItem = new PluginMenuItem("Save whole associated BioPAX as...", action);
        binomIOMenu.add(saveBioPAXMenuItem);
        //saveBioPAXMenuItem.addActionListener(new BioPAXSaveAssociated());

        associateCellDesignerMenuItem = new PluginMenuItem("Associate CellDesigner Source...", action);
        binomIOMenu.add(associateCellDesignerMenuItem);
        //associateCellDesignerMenuItem.addActionListener(CellDesignerAssociateSource.getInstance());
        
        binomIOMenu.addSeparator();        

        listAllReactionsMenuItem = new PluginMenuItem("List all reactions...", action);
        binomIOMenu.add(listAllReactionsMenuItem);
        //listAllReactionsMenuItem.addActionListener(new ListAllReactions());
        
        listAllNodesMenuItem = new PluginMenuItem("List all nodes...", action);
        binomIOMenu.add(listAllNodesMenuItem);
        //listAllNodesMenuItem.addActionListener(new ListAllNodes());


	PluginMenu structAnaMenu = new PluginMenu("BiNoM Analysis");
	addCellDesignerPluginMenu(structAnaMenu);

        menuItem = new PluginMenuItem("Get Connected Components...", action);
	//menuItem.addActionListener(new ConnectedComponents());
	structAnaMenu.add(menuItem);

	menuItem = new PluginMenuItem("Get Strongly Connected Components...", action);
	//menuItem.addActionListener(new StronglyConnectedComponents());
	structAnaMenu.add(menuItem);
	
	
        menuItem = new PluginMenuItem("Prune Graph...", action);
	//menuItem.addActionListener(new PruneGraph());
	structAnaMenu.add(menuItem);

        menuItem = new PluginMenuItem("Get Material Components...", action);
	//menuItem.addActionListener(new MaterialComponents());
	structAnaMenu.add(menuItem);

        menuItem = new PluginMenuItem("Get Cycle Decomposition...", action);
	//menuItem.addActionListener(new CycleDecomposition());
	structAnaMenu.add(menuItem);

	menuItem = new PluginMenuItem("Path Analysis...", action);
	//menuItem.addActionListener(new PathAnalysis());
	structAnaMenu.add(menuItem);
	
	structAnaMenu.addSeparator();
	menuItem = new PluginMenuItem("Generate Modular View...", action);
	//menuItem.addActionListener(new ModularView());
	structAnaMenu.add(menuItem);

	menuItem = new PluginMenuItem("Cluster Networks...", action);
	//menuItem.addActionListener(new ClusterNetworks());
	structAnaMenu.add(menuItem);
	
	structAnaMenu.addSeparator();
	menuItem = new PluginMenuItem("Mono-molecular react.to edges...", action);
	//menuItem.addActionListener(new MonoMolecularReactionsAsEdges());
	structAnaMenu.add(menuItem);
	
	menuItem = new PluginMenuItem("\'Linearize\' network...", action);
	//menuItem.addActionListener(new LinearizeNetwork());
	structAnaMenu.add(menuItem);

	menuItem = new PluginMenuItem("Exclude intermediate nodes...", action);
	//menuItem.addActionListener(new ExcludeIntermediateNodes());
	structAnaMenu.add(menuItem);

	menuItem = new PluginMenuItem("Extract Reaction Network...", action);
	//menuItem.addActionListener(new ExtractReactionNetwork());
	structAnaMenu.add(menuItem);
	
	structAnaMenu.addSeparator();
	menuItem = new PluginMenuItem("Path consistency analysis...", action);
	//menuItem.addActionListener(new PathConsistencyAnalyzer());
	structAnaMenu.add(menuItem);
	
	

	PluginMenu binomBioPAXUtilsMenu = new PluginMenu("BiNoM BioPAX Utils");
        addCellDesignerPluginMenu(binomBioPAXUtilsMenu);

        menuItem = new PluginMenuItem
	    ("BioPAX Property Editor...", action);
        binomBioPAXUtilsMenu.add(menuItem);
        //menuItem.addActionListener(new BioPAXPropertyBrowser());

        menuItem = new PluginMenuItem
	    ("BioPAX Class Tree...", action);
        binomBioPAXUtilsMenu.add(menuItem);
        //menuItem.addActionListener(new BioPAXClassTree());

        toggleBioPAXNameMenuItem = new PluginMenuItem
	    ("Toggle BioPAX Naming Service", action);
        binomBioPAXUtilsMenu.add(toggleBioPAXNameMenuItem);
        //toggleBioPAXNameMenuItem.addActionListener(new BioPAXToggleNamingService());

        syncBioPAXMenuItem = new PluginMenuItem("Synchronize networks with BioPAX...", action);
        binomBioPAXUtilsMenu.add(syncBioPAXMenuItem);
        //syncBioPAXMenuItem.addActionListener(new BioPAXSyncNetworks());

	PluginMenu binomBioPAXQueryMenu = new PluginMenu("BiNoM BioPAX Query ");

	addCellDesignerPluginMenu(binomBioPAXQueryMenu);
	
        PluginMenuItem generateIndexMenuItem = new PluginMenuItem("Generate Index", action);
	binomBioPAXQueryMenu.add(generateIndexMenuItem);
        //generateIndexMenuItem.addActionListener(new BioPAXGenerateIndex());

        PluginMenuItem loadIndexMenuItem = new PluginMenuItem("Load Index", action);
	binomBioPAXQueryMenu.add(loadIndexMenuItem);
        //loadIndexMenuItem.addActionListener(new BioPAXLoadIndex());

        PluginMenuItem displayIndexInfoMenuItem = new PluginMenuItem("Display Index Info", action);
	binomBioPAXQueryMenu.add(displayIndexInfoMenuItem);
        //displayIndexInfoMenuItem.addActionListener(new BioPAXDisplayIndexInfo());
        
        binomBioPAXQueryMenu.addSeparator();

        PluginMenuItem selectEntitiesMenuItem = new PluginMenuItem("Select Entities", action);
	binomBioPAXQueryMenu.add(selectEntitiesMenuItem);
        //selectEntitiesMenuItem.addActionListener(new BioPAXSelectEntities());

        PluginMenuItem standardQueryMenuItem = new PluginMenuItem("Standard Query", action);
	binomBioPAXQueryMenu.add(standardQueryMenuItem);
        //standardQueryMenuItem.addActionListener(new BioPAXStandardQuery());
        
        PluginMenuItem pathIndexAnalysisItem = new PluginMenuItem("Index Path Analysis", action);
    	binomBioPAXQueryMenu.add(pathIndexAnalysisItem);
	//pathIndexAnalysisItem.addActionListener(new BioPAXIndexPathAnalysis());

        PluginMenuItem viewQueryLogMenuItem = new PluginMenuItem("View Query Log", action);
	binomBioPAXQueryMenu.add(viewQueryLogMenuItem);
        //viewQueryLogMenuItem.addActionListener(new BioPAXViewQueryLog());

	// -------------------- Utilities

        PluginMenu binomUtilsMenu = new PluginMenu("BiNoM Utilities");

        addCellDesignerPluginMenu(binomUtilsMenu);

        selectEdgesBetweendSelectedNodesMenuItem = new PluginMenuItem("Select Edges between Selected Nodes", action);
        binomUtilsMenu.add(selectEdgesBetweendSelectedNodesMenuItem);
        //selectEdgesBetweendSelectedNodesMenuItem.addActionListener(new SelectEdgesBetweenSelectedNodes());
	//selectEdgesBetweendSelectedNodesMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F8, 0));
 
        menuItem = new PluginMenuItem("Double Network Differences", action);
        //menuItem.addActionListener(new DoubleNetworkDifference());
        binomUtilsMenu.add(menuItem);

        menuItem = new PluginMenuItem("Update Networks", action);
        //menuItem.addActionListener(new NetworksUpdate());
        binomUtilsMenu.add(menuItem);

        menuItem = new PluginMenuItem("Update connections from other network", action);
        //menuItem.addActionListener(new EdgesFromOtherNetwork());
        binomUtilsMenu.add(menuItem);
        

        PluginMenu clipboardMenu = new PluginMenu("Clipboard");

	binomUtilsMenu.add(clipboardMenu);
	
	setNodesAndEdgesMenuItem = new PluginMenuItem("Copy Selected Nodes and Edges to Clipboard", action);
        clipboardMenu.add(setNodesAndEdgesMenuItem);
        //setNodesAndEdgesMenuItem.addActionListener(new CopySelectedNodesAndEdges(true));

	addNodesAndEdgesMenuItem = new PluginMenuItem("Add Selected Nodes and Edges to Clipboard", action);
        clipboardMenu.add(addNodesAndEdgesMenuItem);
        //addNodesAndEdgesMenuItem.addActionListener(new CopySelectedNodesAndEdges(false));

	pasteNodesAndEdgesMenuItem = new PluginMenuItem("Paste Nodes and Edges from Clipboard", action);
        clipboardMenu.add(pasteNodesAndEdgesMenuItem);
        //pasteNodesAndEdgesMenuItem.addActionListener(new PasteNodesAndEdges());

	showClipboardContentsMenuItem = new PluginMenuItem("Show Clipboard Contents", action);
        clipboardMenu.add(showClipboardContentsMenuItem);
        //showClipboardContentsMenuItem.addActionListener(new ShowClipboardContents());

    }
	
	
    public void addPluginMenu() {
	System.out.println("addPluginMenu");
    }

    public void SBaseAdded(PluginSBase sbase) {
	System.out.println("SBaseAdded");
    }

    public void SBaseChanged(PluginSBase sbase) {
	System.out.println("SBaseChanged");
    }

    public void SBaseDeleted(PluginSBase sbase) {
	System.out.println("SBaseDeleted");
    }

    public void modelOpened(PluginSBase sbase) {
	System.out.println("modelOpened");
    }

    public void modelSelectChanged(PluginSBase sbase) {
	System.out.println("modelSelectChanged");
    }

    public void modelClosed(PluginSBase sbase) {
	System.out.println("modelClosed");
    }
}
