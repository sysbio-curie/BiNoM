package fr.curie.BiNoM.pathways.analysis.structure;

import java.io.*;
import java.util.*;

public class Path {

	// This should be set up
	public Graph graph = null;
	public int source = -1;
	public int target = -1;
	
	public Vector<Node> nodeSequence = new Vector<Node>();

	// This is calculated by calcPathProperties
	public int length = 0;
	public float influence = 0;
	public String label = null;
	
	// This is calculated by getPathConsistencyAndSummaryActivity
	public int consistency = 0; // 1 - all active nodes on the pathway has the same influence type, -1 - not the same, 0 - not checked 
	public float summaryActivity = 0; // sum of all influences of active nodes along the path
	public int numberOfActiveNodes = 0; // sum of all influences of active nodes along the path
	
	
	public boolean selected = true;

}
