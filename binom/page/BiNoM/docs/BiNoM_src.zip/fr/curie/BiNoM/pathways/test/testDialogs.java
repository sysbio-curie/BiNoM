package fr.curie.BiNoM.pathways.test;

import java.util.*;
import fr.curie.BiNoM.pathways.wrappers.*;
import fr.curie.BiNoM.pathways.*;
import fr.curie.BiNoM.cytoscape.utils.*;

import edu.rpi.cs.xgmml.*;
import org.sbml.x2001.ns.celldesigner.*;

public class testDialogs {

	public static void main(String[] args) {
		
		try{
			
			String file = "c:/datas/binomtest/text/simple.owl";
			BioPAX biopax = new BioPAX();
			biopax.loadBioPAX(file);
			
			GraphDocument grDoc = (BioPAXToCytoscapeConverter.convert(BioPAXToCytoscapeConverter.REACTION_NETWORK_CONVERSION, file, new BioPAXToCytoscapeConverter.Option())).graphDocument;

			ListAllReactionsDialog dialog = new ListAllReactionsDialog();
			dialog.pop(grDoc,null,biopax);
			
			
			/*String file = "c:/datas/binomtest/M-Phase2.xml";
			CellDesigner cd = new CellDesigner();
			org.sbml.x2001.ns.celldesigner.SbmlDocument cdsbml = cd.loadCellDesigner(file);
			
			cd.entities = cd.getEntities(cdsbml);
			GraphDocument grDoc = CellDesignerToCytoscapeConverter.getXGMMLGraph("M-Phase2", cdsbml.getSbml());

			ListAllReactionsDialog dialog = new ListAllReactionsDialog();
			//dialog.pop(grDoc,cdsbml,null);
			dialog.pop(grDoc,cdsbml,null);*/
			
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
