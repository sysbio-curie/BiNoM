/*
BiNoM Cytoscape Plugin
Copyright (C) 2006-2007 Curie Institute, 26 rue d'Ulm, 75005 Paris - FRANCE

BiNoM Cytoscape Plugin is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

BiNoM Cytoscape plugin is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/*
BiNoM authors:
	Andrei Zinovyev : http://www.ihes.fr/~zinovyev
	Eric Viara : http://www.sysra.com/viara
	Laurence Calzone :	http://leibniz.biol.vt.edu/people/laurence/laurence.html
*/
package fr.curie.BiNoM.cytoscape.analysis;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.*;

import javax.swing.JFrame;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.view.CyNetworkView;
import edu.rpi.cs.xgmml.GraphDocument;
import fr.curie.BiNoM.cytoscape.ain.ImportFromAINDialogFamily;
import fr.curie.BiNoM.cytoscape.biopax.BioPAXSourceDB;
import fr.curie.BiNoM.cytoscape.lib.GraphDocumentFactory;
import fr.curie.BiNoM.cytoscape.lib.NetworkFactory;
import fr.curie.BiNoM.pathways.analysis.structure.BiographUtils;
import fr.curie.BiNoM.pathways.analysis.structure.Graph;
import fr.curie.BiNoM.pathways.wrappers.BioPAX;
import fr.curie.BiNoM.pathways.wrappers.XGMML;

public class ExcludeIntermediateNodes implements ActionListener {
	
	public static ExcludeIntermediateNodesDialog dialog;	

	public void actionPerformed(ActionEvent e) {
		
		GraphDocument graphDocument = GraphDocumentFactory.createGraphDocument
	    (Cytoscape.getCurrentNetwork());

	CyNetworkView view = Cytoscape.getCurrentNetworkView();
	
	
	
	//ExcludeIntermediateNodesTask task = new ExcludeIntermediateNodesTask
	//    (graphDocument,
	//     Cytoscape.getCurrentNetworkView().getVisualStyle());
	//fr.curie.BiNoM.cytoscape.lib.TaskManager.executeTask(task);

	Graph graph = XGMML.convertXGMMLToGraph(graphDocument);
	Vector v = new Vector();
    Graph grres = BiographUtils.ExcludeIntermediateNodes(graph,v,true);
    
	JFrame window = new JFrame();
	dialog = new ExcludeIntermediateNodesDialog(window,"Choose nodes to exclude",true);
	dialog.pop(v);
	
	if(dialog.result>0){
	
	grres = BiographUtils.ExcludeIntermediateNodes(graph,dialog.nodesToExclude,false);
    
    GraphDocument grDoc = XGMML.convertGraphToXGMML(grres);
	//GraphDocument grDoc = null;

    try{
    	
	BioPAX biopax = BioPAXSourceDB.getInstance().getBioPAX(Cytoscape.getCurrentNetwork());
    	
    	
	CyNetwork cyNetwork = NetworkFactory.createNetwork
	    (grDoc.getGraph().getName()+".inter_excluded",
	     grDoc,
	     Cytoscape.getCurrentNetworkView().getVisualStyle(),
	     false, // applyLayout
	     null);
	
	if(biopax!=null)
		BioPAXSourceDB.getInstance().setBioPAX(cyNetwork, biopax);
	
	
    }catch(Exception ee){
    	ee.printStackTrace();
    }
	}
	
	}

}
